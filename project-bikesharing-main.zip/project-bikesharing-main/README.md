- 👋 Hi, I’m @AIME2021KE
- 🌱 I’m currently learning ... deep learning
- 📫 How to reach me ...

<!---
AIME2021KE/AIME2021KE is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
This repository is to try to share my problem area in the bike-sharing project for deep learning
